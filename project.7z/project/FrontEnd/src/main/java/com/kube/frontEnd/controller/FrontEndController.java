package com.kube.frontEnd.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.kuber.frontEnd.entiry.Student;
import com.kuber.frontEnd.entiry.Students;


@Controller
//@RequestMapping("/frontend")
public class FrontEndController {
	@Value("${restUrlAdd}")
	private String restUrlAdd;
	
	@Value("${restUrlGetAll}")
	private String restUrlGetAll;
	
	private static final Logger logger = LoggerFactory.getLogger(FrontEndController.class);
	
	@RequestMapping("/")
	public String viewLoginPage(Model model) {
		model.addAttribute("student", new Student());
		return "index";
	}
	
	@RequestMapping(value="/addStudent", method= RequestMethod.POST)
	private String addStudent(@ModelAttribute("student") Student student, Model model){
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.postForObject(restUrlAdd, student, Student.class);
		model.addAttribute("message", "Data is inserted");
		return "index";
	}

	@RequestMapping(value="/getAllStudents", method= RequestMethod.GET)
	private String getAllStudents(Model model) {
		RestTemplate restTemplate = new RestTemplate();
		Students students =  restTemplate.getForObject(restUrlGetAll, Students.class);
		model.addAttribute("liststudents", students.getStudents());
		return "display";
	}
}
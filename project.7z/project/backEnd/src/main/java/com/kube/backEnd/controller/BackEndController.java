package com.kube.backEnd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kube.backEnd.entity.Student;
import com.kube.backEnd.entity.Students;
import com.kube.backEnd.repository.StudentRepository;
import com.kube.backEnd.repository.StudentsRepository;



@RestController
@RequestMapping("/backend")
public class BackEndController {
	
	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	StudentsRepository studentsRepository;
	
	@PostMapping("/addStudent")
	private Student addStudent(@RequestBody Student student){
		Student studentResp=studentRepository.save(student);
		return studentResp;
	}

	@GetMapping("/getAllStudents")
	private Students getAllStudents() {
		List<Student> studentsList=studentRepository.findAll();
		Students students = new Students();
		students.setStudents(studentsList);
		return students;
	}
	
}
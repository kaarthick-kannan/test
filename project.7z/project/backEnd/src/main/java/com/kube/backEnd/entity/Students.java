package com.kube.backEnd.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Students {
	List<Student> students;

	public List<Student> getStudents() {
		if (students != null) {
			return students;
		} else {
			return new ArrayList<>();
		}
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}